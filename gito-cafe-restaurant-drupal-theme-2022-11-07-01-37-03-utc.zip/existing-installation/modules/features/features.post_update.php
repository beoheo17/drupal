<?php

/**
 * @file
 * Post update functions for Features.
 */

/**
 * Clear caches due to changes in service arguments.
 */
function features_post_update_d9_compatibility() {
  // Empty post-update hook.
}
